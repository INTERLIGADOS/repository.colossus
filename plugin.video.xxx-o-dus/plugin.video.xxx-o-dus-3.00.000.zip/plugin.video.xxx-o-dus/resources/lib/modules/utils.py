import xbmc,xbmcgui,xbmcplugin,sys,urllib,urlparse,os,base64,re
import kodi
import client
import cache
import log_utils
from url_dispatcher import URL_Dispatcher
url_dispatcher = URL_Dispatcher()

def parse_query(query):
    toint = ['page', 'download', 'favmode', 'channel', 'section']
    q = {'mode': '0'}
    if query.startswith('?'): query = query[1:]
    queries = urlparse.parse_qs(query)
    for key in queries:
        if len(queries[key]) == 1:
            if key in toint:
                try: q[key] = int(queries[key][0])
                except: q[key] = queries[key][0]
            else:
                q[key] = queries[key][0]
        else:
            q[key] = queries[key]
    return q
    
def buildDir(items, content='dirs', cm=[], search=False, stopend=False, isVideo = False, isDownloadable = False, cache=True, chaturbate=False):

        if items == None or len(items) == 0:
            xbmc.executebuiltin('Dialog.Close(busydialog)')
            sys.exit()

        sysaddon = sys.argv[0]
        syshandle = int(sys.argv[1])

        for i in items:
        
            name = i['name']
            if 'file_path' not in name:
                name = client.replaceHTMLCodes(name)
                name = kodi.sortX(name)
            else: name = name.replace('file_path','')
            item = xbmcgui.ListItem(label=name)

            try: 
                if i['description']: description = i['description']
            except: description = name
                
            kodi.giveColor(description, 'white', True)
            item.setInfo('video', {'title': name, 'plot': description} )

            try:
                if i['url']: url = i['url']
                else: url = 'none'
            except: url = 'none'
            if i['icon'] == None: thumb=kodi.addonicon
            else: thumb = i['icon']
            if i['fanart'] == None: fanart=kodi.addonicon
            else: fanart = i['fanart']
            if ( not thumb == 'local' ) and ( not fanart == 'local' ):
                item.setArt({'icon': thumb, 'thumb': thumb, 'fanart': fanart})
            else:
                item.setArt({'icon': url, 'thumb': url, 'fanart': fanart})
                
            try:
                if i['folder']: _folder = True
                else: _folder = False
            except: _folder = True

            try:
                if i['isDownloaded']: isDownloaded = True
                else: isDownloaded = False
            except: isDownloaded = False

            if not isDownloadable:
                try:
                    if i['isDownloadable']: isDownloadable = True
                    else: isDownloadable = False
                except: isDownloadable = False
           
            if 'typeid=history' in url:
                url = url.replace('typeid=history','')
                history = '%s?url=%s&mode=%s' \
                % (sysaddon,urllib.quote_plus(url),str('24'))
                htext = "Remove from History"
                cm.append(('%s' % htext, 'xbmc.RunPlugin('+history+')'))

            if 'search_term=' in url:
                search_term = '%s?url=%s&mode=%s' \
                % (sysaddon,urllib.quote_plus(url),str('25'))
                stext = "Remove Search Term"
                cm.append(('%s' % stext, 'xbmc.RunPlugin('+search_term+')'))
                url = url.replace('search_term=','')
                
            u= '%s?url=%s&mode=%s&name=%s&iconimage=%s&fanart=%s' \
            % (sysaddon,urllib.quote_plus(url),str(i['mode']),urllib.quote_plus(name),urllib.quote_plus(thumb),urllib.quote_plus(fanart))

            try: 
                if i['fav']: fav = i['fav']
                else: fav = 'add'
            except: fav = 'add'

            try: 
                if i['cm']:
                    for cmitems in i['cm']:
                        log_utils.log('%s' % (cmitems[1]), log_utils.LOGNOTICE)
                        cm.append(('%s' % cmitems[0], 'xbmc.RunPlugin('+cmitems[1]+')'))
            except: pass
            
            if isDownloadable:
                dwnld = '%s?url=%s&mode=%s&name=%s&iconimage=%s' \
                % (sysaddon,urllib.quote_plus(url),str('26'),urllib.quote_plus(name),urllib.quote_plus(thumb))
                cm.append(('Download Video', 'xbmc.RunPlugin('+dwnld+')'))
            if isDownloaded:
                rmdwnld = '%s?url=%s&mode=%s&name=%s' \
                % (sysaddon,urllib.quote_plus(url),str('28'),urllib.quote_plus(name))
                cm.append(('Delete Video', 'xbmc.RunPlugin('+rmdwnld+')'))
                
            favorite = '%s?url=%s&mode=%s&name=%s&iconimage=%s&fav=%s&favmode=%s&folder=%s' \
            % (sysaddon,urllib.quote_plus(url),str('100'),urllib.quote_plus(name),urllib.quote_plus(thumb),fav,str(i['mode']),str(_folder))
            
            if fav == 'add': ftext = "Add to"
            elif fav == 'del': ftext = "Remove from"
            cm.append(('%s %s Favorites' % (ftext, kodi.get_name()), 'xbmc.RunPlugin('+favorite+')'))

            if cm: 
                item.addContextMenuItems(cm, replaceItems=False)
                cm=[]

            if isVideo:
                codec_info = {'codec': 'h264'}
                item.addStreamInfo('video', codec_info)
            
            xbmcplugin.addDirectoryItem(handle=syshandle, url=u, listitem=item, isFolder=_folder)

        if (not search) and (not stopend): 
            if chaturbate: kodi.setView('list')
            elif isVideo: kodi.setView('thumbs')
            else: kodi.setView('list')
            if cache: xbmcplugin.endOfDirectory(syshandle, cacheToDisc=True)
            else: xbmcplugin.endOfDirectory(syshandle, cacheToDisc=False)
        
def resolverCheck():

    try:
        file = xbmc.translatePath(os.path.join('special://home/addons/' + kodi.get_id() , 'resources/lib/modules/adultresolver.py'))
        if not os.path.isfile(file):
            f = open(file,'w'); f.close()
            r = client.request(base64.b64decode('aHR0cDovL2VjaG9jb2Rlci5vZmZzaG9yZXBhc3RlYmluLmNvbS9hZGRvbnMveHh4b2R1cy9yZXNvbHZlci54bWw='))
        else:
            r = cache.get(client.request, 1, base64.b64decode('aHR0cDovL2VjaG9jb2Rlci5vZmZzaG9yZXBhc3RlYmluLmNvbS9hZGRvbnMveHh4b2R1cy9yZXNvbHZlci54bWw='))
        r = re.compile('<link>(.+?)</link>').findall(r)[0]
        supported=cache.get(client.request, 1, r)
        if len(supported)>1:
            if 'import' in supported:
                comparefile = file
                r = open(comparefile)
                compfile = r.read()       
                if compfile == supported:pass
                else:
                    text_file = open(comparefile, "w")
                    text_file.write(supported)
                    text_file.close()
                    kodi.notify(msg='Adult Resolver Updated.', duration=7500, sound=True)
    except: pass
    
@url_dispatcher.register('19')
def showSettings():
    kodi.show_settings()
# -*- coding: utf-8 -*-
#
# Copyright (C) 2014 Sean Poyser and Richard Dean (write2dixie@gmail.com)
#
#      Modified for FTV Guide (09/2014 onwards)
#      by Thomas Geppert [bluezed] - bluezed.apps@gmail.com
#
#      Modified for Assassins TV Guide (2016)
#      by primaeval - primaeval.dev@gmail.com
#
# This Program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2, or (at your option)
# any later version.
#
# This Program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with XBMC; see the file COPYING. If not, write to
# the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
# http://www.gnu.org/copyleft/gpl.html
#

import os
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs


def deleteDB():
    try:
        xbmc.log("[script.tvguide.Assassins] Deleting database...", xbmc.LOGDEBUG)
        dbPath = xbmc.translatePath(xbmcaddon.Addon(id = 'script.tvguide.Assassins').getAddonInfo('profile'))
        dbPath = os.path.join(dbPath, 'source.db')

        delete_file(dbPath)

        passed = not os.path.exists(dbPath)

        if passed:
            xbmc.log("[script.tvguide.Assassins] Deleting database...PASSED", xbmc.LOGDEBUG)
        else:
            xbmc.log("[script.tvguide.Assassins] Deleting database...FAILED", xbmc.LOGDEBUG)

        return passed

    except Exception, e:
        xbmc.log('[script.tvguide.Assassins] Deleting database...EXCEPTION', xbmc.LOGDEBUG)
        return False

def delete_file(filename):
    tries = 10
    while os.path.exists(filename) and tries > 0:
        try:
            os.remove(filename)
            break
        except:
            tries -= 1

if __name__ == '__main__':
    if len(sys.argv) > 1:
        mode = int(sys.argv[1])

        if mode in [1,2,6]:
            if deleteDB():
                d = xbmcgui.Dialog()
                d.ok('Assassins TV Guide', '[COLOR green]Reset has been Successful[/COLOR]', 'Please now restart Assassins TV Guide')
            else:
                d = xbmcgui.Dialog()
                d.ok('Assassins TV Guide', 'Failed to delete database.', 'Database may be locked,', 'Restart Kodi and Try Again')
        elif mode in [10]:
            if deleteDB():
                d = xbmcgui.Dialog()
                d.ok('Assassins TV Guide', '[COLOR green]Switchover has been Successful[/COLOR]', 'Thankyou for choosing Assassins TV Guide')
            else:
                d = xbmcgui.Dialog()
                d.ok('Assassins TV Guide', 'Switchover Failed', 'Restart Kodi and Try Again')
        elif mode in [5]:
            if deleteDB():
                d = xbmcgui.Dialog()
                d.ok('Assassins TV Guide', '[COLOR green]All DONE[/COLOR]', 'All addons.ini files have been deleted')
            else:
                d = xbmcgui.Dialog()
                d.ok('Assassins TV Guide', '[COLOR green]All DONE[/COLOR]', 'Addons.ini files have been deleted')
        elif mode in [8]:
            if deleteDB():
                d = xbmcgui.Dialog()
                d.ok('Assassins TV Guide', '[COLOR green]Your IPTV Service is now ready for ini Creation[/COLOR]', 'Click Create Button (Above) to complete set-up, Then Open Assassins Guide')
            else:
                d = xbmcgui.Dialog()
                d.ok('Assassins TV Guide', '[COLOR green]Your IPTV Service is now ready for ini Creation[/COLOR]', 'Click Create Button (Above) to complete set-up, Then Open Assassins Guide')				
        if mode == 1:
            xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/guide.xml')
            xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/guide.xml.md5')
            xbmcvfs.delete('special://profile/addon_data/plugin.video.FMG/settings.xml')
        if mode == 2:
            xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/addons.ini')
            xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/addons.ini.local')
            xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/category_count.ini')
            xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/categories.ini')
            xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/custom_stream_urls.ini')
            xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/channel_id_title.ini')
            xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/mapping.ini')
            xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/custom_stream_urls_autosave.ini')
            xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/icons.ini')
            xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/folders.list')
            xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/tvdb.pickle')
            xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/tvdb_banners.pickle')
            xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/settings.xml')
            xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/guide.xml')
            xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/guide.xml.md5')
            xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/subscriptions.ini')
            xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/channels.ini')
            xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/synopsis_search.list')
            xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/title_search.list')
            xbmcvfs.delete('special://profile/addon_data/plugin.video.FMG/settings.xml')
            dirs, files = xbmcvfs.listdir('special://profile/addon_data/script.tvguide.Assassins/')
            for f in files:
                xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/%s' % f)				
        if mode == 3:
            xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/tvdb.pickle')
            xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/tvdb_banners.pickle')
        if mode in [2,4]:
            dirs, files = xbmcvfs.listdir('special://profile/addon_data/script.tvguide.Assassins/logos')
            for f in files:
                xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/logos/%s' % f)
        if mode == 5:
            xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/addons.ini')
            xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/addons.ini.local')
            xbmcvfs.delete('special://profile/addons_custom.ini')
            xbmcvfs.delete('special://profile/addon_data/plugin.video.FMG/settings.xml')
            xbmcvfs.delete('special://profile/addon_data/plugin.video.aini/.storage/folders')			
        if mode == 6:
            xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/synopsis_search.list')
            xbmcvfs.delete('special://profile/addon_data/script.tvguide.Assassins/title_search.list')
        if mode == 7:	
            xbmcvfs.delete('special://home/userdata/addon_data/script.tvguide.Assassins/settings.xml')
        if mode == 8:
            xbmcvfs.copy('special://home/addons/script.tvguide.Assassins/resources/services/Achilles/folders','special://profile/addon_data/plugin.video.aini/.storage/folders'), 		
        if mode == 10:	
            xbmcvfs.copy('special://profile/addon_data/script.tvguide.echo/subscriptions.ini','special://profile/addon_data/script.tvguide.Assassins/subscriptions.ini'),
            xbmcvfs.copy('special://profile/addon_data/script.tvguide.echo/addons.ini','special://profile/addon_data/script.tvguide.Assassins/addons.ini'),
            xbmcvfs.copy('special://profile/addon_data/script.tvguide.echo/addons.ini.local','special://profile/addon_data/script.tvguide.Assassins/addons.ini.local'),
            xbmcvfs.copy('special://profile/addon_data/script.tvguide.echo/category_count.ini','special://profile/addon_data/script.tvguide.Assassins/category_count.ini'),
            xbmcvfs.copy('special://profile/addon_data/script.tvguide.echo/categories.ini','special://profile/addon_data/script.tvguide.Assassins/categories.ini'),
            xbmcvfs.copy('special://profile/addon_data/script.tvguide.echo/custom_stream_urls.ini','special://profile/addon_data/script.tvguide.Assassins/custom_stream_urls.ini'),
            xbmcvfs.copy('special://profile/addon_data/script.tvguide.echo/channel_id_title.ini','special://profile/addon_data/script.tvguide.Assassins/channel_id_title.ini'),
            xbmcvfs.copy('special://profile/addon_data/script.tvguide.echo/mapping.ini','special://profile/addon_data/script.tvguide.Assassins/mapping.ini'),
            xbmcvfs.copy('special://profile/addon_data/script.tvguide.echo/custom_stream_urls_autosave.ini','special://profile/addon_data/script.tvguide.Assassins/custom_stream_urls_autosave.ini'),
            xbmcvfs.copy('special://profile/addon_data/script.tvguide.echo/source.db','special://profile/addon_data/script.tvguide.Assassins/source.db')
            dirs, files = xbmcvfs.listdir('special://profile/addon_data/script.tvguide.echo/backgrounds/')
            for f in files:
                xbmcvfs.delete('special://profile/addon_data/script.tvguide.echo/backgrounds/%s' % f)
            dirs, files = xbmcvfs.listdir('special://profile/addon_data/script.tvguide.echo/')
            for f in files:
                xbmcvfs.delete('special://profile/addon_data/script.tvguide.echo/%s' % f)
            xbmcvfs.rmdir('special://profile/addon_data/script.tvguide.echo/backgrounds')
            xbmcvfs.rmdir('special://profile/addon_data/script.tvguide.echo')			
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/art/')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/art/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/FMG/')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/FMG/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/English')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/English/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/English (Australia)')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/English (Australia)/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/English (New Zealand)')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/English (New Zealand)/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/English (US)')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/English (US)/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Afrikaans')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Afrikaans/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Albanian')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Albanian/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Amharic')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Amharic/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Arabic')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Arabic/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Basque')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Basque/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Belarusian')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Belarusian/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Bosnian')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Bosnian/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Bulgarian')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Bulgarian/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Burmese')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Burmese/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Catalan')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Catalan/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Chinese (Simple)')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Chinese (Simple)/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Chinese (Traditional)')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Chinese (Traditional)/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Croatian')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Croatian/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Czech')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Czech/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Danish')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Danish/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Dutch')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Dutch/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Esperanto')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Esperanto/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Estonian')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Estonian/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Faroese')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Faroese/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Finnish')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Finnish/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/French')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/French/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/French (Canada)')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/French (Canada)/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Galician')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Galician/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Georgian')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Georgian/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/German')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/German/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Greek')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Greek/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Haitian (Haitian Creole)')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Haitian (Haitian Creole)/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Hebrew')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Hebrew/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Hindi (Devanagiri)')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Hindi (Devanagiri)/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Hungarian')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Hungarian/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Icelandic')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Icelandic/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Indonesian')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Indonesian/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Italian')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Italian/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Japanese')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Japanese/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Korean')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Korean/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Latvian')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Latvian/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Lithuanian')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Lithuanian/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Macedonian')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Macedonian/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Malay')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Malay/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Malayalam')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Malayalam/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Maltese')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Maltese/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Norwegian')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Norwegian/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Persian')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Persian%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Persian')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Persian/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Persian (Iran)')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Persian (Iran)/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Polish')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Polish/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Portuguese')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Portuguese/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Portuguese (Brazil)')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Portuguese (Brazil)/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Romanian')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Romanian/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Russian')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Russian/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Serbian/')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Serbian/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Serbian (Cyrillic)')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Serbian (Cyrillic)/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Slovak')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Slovak/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Slovenian')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Slovenian/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Spanish')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Spanish/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Spanish (Argentina)')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Spanish (Argentina)/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Spanish (Mexico)')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Spanish (Mexico)/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Swedish')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Swedish/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Tamil (India)')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Tamil (India)/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Thai')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Thai/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Turkish')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Turkish/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Ukrainian')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Ukrainian/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Uzbek')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Uzbek/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Vietnamese')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Vietnamese/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Vietnamese (Viet Nam)')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Vietnamese (Viet Nam)/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/language/Welsh')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/language/Welsh/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Africa')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Africa/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/America/Argentina')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/America/Argentina/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/America/Indiana/')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/America/Indiana/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/America/Kentucky')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/America/Kentucky/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/America/')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/America/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/America/North_Dakota')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/America/North_Dakota/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Antarctica')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Antarctica/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Australia')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Australia/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Arctic')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Arctic/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Asia')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Asia/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Atlantic')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Atlantic/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Brazil')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Brazil/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Canada')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Canada/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Chile')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Chile/%s' % f)	
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Etc')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Etc/%s' % f)	
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Europe')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Europe/%s' % f)	
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Indian')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Indian/%s' % f)	
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Mexico')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Mexico/%s' % f)	
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Pacific')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/Pacific/%s' % f)	
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/US')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/lib/pytz/zoneinfo/US/%s' % f)	
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/lib/pytz')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/lib/pytz/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/lib')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/lib/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/playwith/Android')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/playwith/Android/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/playwith')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/playwith/%s' % f)	
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/screenshots/')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/screenshots/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/skins/default/720p')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/skins/default/720p/%s' % f)	
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/skins/default/')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/skins/default/%s' % f)	
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/skins/default/media')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/skins/default/media/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/skins/Red/720p')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/skins/Red/720p/%s' % f)	
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/skins/Red/media')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/skins/Red/media/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/skins/Echo Q/720p')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/skins/Echo Q/720p/%s' % f)	
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/skins/Echo Q/media')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/skins/Echo Q/media/%s' % f)
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/resources/')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/resources/%s' % f)	
            dirs, files = xbmcvfs.listdir('special://home/addons/script.tvguide.echo/')
            for f in files:
                xbmcvfs.delete('special://home/addons/script.tvguide.echo/%s' % f)	
            xbmcvfs.delete('special://home/addons/script.tvguide.echo/.gitignore')				
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/art') 
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/FMG')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/English')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/English (Australia)')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/English (New Zealand)')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/English (US)')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Afrikaans')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Albanian')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Amharic')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Arabic')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Basque')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Belarusian')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Bosnian')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Bulgarian')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Burmese')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Catalan')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Chinese (Simple)')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Chinese (Traditional)')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Croatian')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Czech')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Danish')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Dutch')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Esperanto')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Estonian')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Faroese')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Finnish')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/French')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/French (Canada)')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Galician')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Georgian')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/German')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Greek')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Haitian (Haitian Creole)')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Hebrew')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Hindi (Devanagiri)')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Hungarian')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Icelandic')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Indonesian')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Italian')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Japanese')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Korean')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Latvian')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Lithuanian')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Macedonian')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Malay')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Malayalam')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Maltese')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Norwegian')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Persian')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Persian (Iran)')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Polish')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Portuguese')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Portuguese (Brazil)')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Romanian')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Russian')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Serbian')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Serbian (Cyrillic)')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Slovak')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Slovenian')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Spanish')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Spanish (Argentina)')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Spanish (Mexico)')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Swedish')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Tamil (India)')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Thai')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Turkish')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Ukrainian')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Uzbek')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Vietnamese')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Vietnamese (Viet Nam)')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language/Welsh')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/Language')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/lib/pytz/zoneinfo/Africa')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/lib/pytz/zoneinfo/America/Argentina')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/lib/pytz/zoneinfo/America/Indiana')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/lib/pytz/zoneinfo/America/Kentucky')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/lib/pytz/zoneinfo/America/North_Dakota')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/lib/pytz/zoneinfo/America')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/lib/pytz/zoneinfo/Antarctica')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/lib/pytz/zoneinfo/Arctic')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/lib/pytz/zoneinfo/Asia')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/lib/pytz/zoneinfo/Atlantic')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/lib/pytz/zoneinfo/Australia') 
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/lib/pytz/zoneinfo/Brazil')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/lib/pytz/zoneinfo/Canada')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/lib/pytz/zoneinfo/Chile')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/lib/pytz/zoneinfo/Etc')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/lib/pytz/zoneinfo/Europe')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/lib/pytz/zoneinfo/Indian')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/lib/pytz/zoneinfo/Mexico')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/lib/pytz/zoneinfo/Pacific')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/lib/pytz/zoneinfo/US')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/lib/pytz/zoneinfo')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/lib/pytz')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/lib')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/playwith/Android')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/playwith')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/screenshots')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/skins/Default/720p')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/skins/Default/media')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/skins/Default')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/skins/Red/720p')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/skins/Red/media')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/skins/Red')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/skins/Echo Q/720p')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/skins/Echo Q/media')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/skins/Echo Q')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources/skins')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo/Resources')
            xbmcvfs.rmdir('special://home/addons/script.tvguide.echo')
				
				
				
				
				
				
				
				
				
				
				
				
				
				
